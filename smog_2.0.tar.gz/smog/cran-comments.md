## Test environments
* linux-gnu (64-bit), R 3.5.1
* Ubuntu Linux 16.04, R 3.4.4
* w64-mingw32 (64-bit), R 3.5.1

## R CMD check results
There were no ERRORs or WARNINGs. 

There was 1 NOTE:

* checking CRAN incoming feasibility ... NOTE
Maintainer: 'Chong Ma <chong.ma@yale.edu>'